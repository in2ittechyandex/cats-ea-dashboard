import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import 'rxjs/add/operator/map';

import { Config } from 'src/app/config/app-configuartion';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
 
const CHAT_URL = "ws://172.27.64.91:9009/ws/chat/yash/";

export interface Message {
  data:any[]; 
}
@Injectable({
  providedIn: 'root'
})
export class SummaryService { 
  /**
     * 
     * @param http 
     * @param commonService 
     */
    constructor(private http: HttpClient, private config: Config) {
      
     }

    /**
     * 
     * to get all System Overview
     * 
     */
    getAllSystemOverview() {
      var URL = environment.ApiURLNew + "eventengine/noisereduction";
      return this.http.get(URL).map(res=><any>res);
    }
    /**
     * 
     * to get today System Overview
     * 
     */

    getAllSystemOverviewToday(){
      var URL = environment.ApiURLNew + "eventengine/noisereduction?time=1320076543";
      // URL= "http://172.16.61.151:8000/eventengine/noisereduction?time=1320076543";
      return this.http.get(URL).map(res=><any>res);
    }
    /**
     * 
     * to get nms details 
     * Tech
     */

    getNMSOverview(){
      var URL = environment.ApiURLNew + "eventengine/noisereduction3";
      URL= environment.ApiURLNew + "eventengine/summary_nms_counts";
      return this.http.get(URL).map(res=><any>res);
    }
     /**
     * 
     * to get Tech details 
     * 
     */

    getTechOverview(days){
      var URL = environment.ApiURLNew + "eventengine/noisereduction3";
      URL= environment.ApiURLNew + "eventengine/summary_counts?day="+days;
      return this.http.get(URL).map(res=><any>res);
    }

    getTechInnerData(techkey,days){
      var URL = environment.ApiURLNew + "eventengine/noisereduction3";
      URL= environment.ApiURLNew + "eventengine/summary?tech="+techkey+"&day="+days;
      return this.http.get(URL).map(res=><any>res);
    }
     
    private getAuthorizedHeader(): Headers {
      let headers = new Headers();
      headers.append('langCode', this.config.getUserLang().toUpperCase());
      var data = JSON.parse(localStorage.getItem("currentUser"));
      // headers.append('Token', ""+ data.token)
      headers.append('Authorization', 'Token ' + data.token)
      return headers;
  }

}
 