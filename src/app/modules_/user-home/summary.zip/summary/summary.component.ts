
import { Component, OnInit, OnDestroy } from '@angular/core';
import { SummaryService } from './summary.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
// import { EventsService } from '../events/events.service';
import themeConf_ from '../../../config/theme-settings';
import { Subscription } from 'rxjs';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
// import { $WebSocket, WebSocketSendMode } from 'angular2-websocket/angular2-websocket';
import { Title } from '@angular/platform-browser';
// import { WebsocketserviceService } from './websocketservice.service';
// import { TimeFilterService } from 'src/time-filter/time-filter.service.component';
import { environment } from 'src/environments/environment';
import { TimeFilterService } from 'src/app/shared_/time-filter/time-filter.service.component';
@Component({
  selector: 'cats-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit, OnDestroy {
  public connection;
  systemViewmodel = {
    "Total_Event": 0,
    "Total_Incident": 0,
    "Total_Automation": 0,
    "Automation_Success": 0,
    "Total_Enrichment": 0,
    "Noise_Reduction": 0,
    "Alert_Count": 0
  }
  systemViewmodelToday = {
    "Total_Event": 0,
    "Total_Incident": 0,
    "Total_Automation": 0,
    "Automation_Success": 0,
    "Total_Enrichment": 0,
    "Noise_Reduction": 0,
    "day": "",
    "Alert_Count": 0
  }
  systemViewNms = [];
  systemViewService = [];
  themeConf_;
  loading: boolean = false;
  // ws: $WebSocket;
  constructor(private slimLoadingBarService: SlimLoadingBarService,
    private summaryService: SummaryService,
    private router: Router,
    // private webSocketService: WebsocketserviceService,
    private route: ActivatedRoute,
    //  private eventService: EventsService,
    private title: Title,
    private timeServices_:TimeFilterService
  ) {
    // if(!environment.production){
    //   this.ws = new $WebSocket(environment._SOCKET_URL);
    // }

  }
  private timeout;


  blink(msg: string, count: number = 5): void {
    const prevTitle = this.title.getTitle();

    const step = () => {
      const newTitle = this.title.getTitle() === prevTitle ?
        msg : prevTitle;

      this.title.setTitle(newTitle);

      if (--count) {
        this.timeout = setTimeout(step.bind(this), 1000);
      } else {
        this.title.setTitle(prevTitle);
      }
    };

    clearTimeout(this.timeout);
    step();
  }
  startLoading() {
    this.slimLoadingBarService.start(() => {
      // console.log('Loading complete');
    });
  }

  stopLoading() {
    this.slimLoadingBarService.stop();
  }

  completeLoading() {
    this.slimLoadingBarService.complete();
  }
  toggle = false;
  radio(techkey) {
    // this.toggle=!this.toggle;
    var flag: boolean = document.getElementById(techkey).hidden;
    if (!flag) {
      if (this.tabOpened.includes(techkey)) {
        this.tabOpened.splice(techkey);
      }
      localStorage.setItem('tabopened', JSON.stringify(this.tabOpened));
      document.getElementById(techkey).hidden = true;
      return;
    }
    this.getTechInnerData(techkey);

  }
  situationConains(name) {
    if (this.situation_data !== undefined) {
      for (var i = 0; i < this.situation_data.length; i++) {
        if (this.situation_data[i].tech === name) {
          return true;
        }
      }
    }
  }
  navigateToDevOps(name) {
    if (this.situationConains(name)) {
      this.router.navigateByUrl('dashboard/engineer-view/cloud-dev-ops');
    }
  }
  situation_data: any[] = [];
  timeRangeLastSevenDay = "";
  timeRangeToday = "";
  ngOnInit() {
    this.themeConf_ = themeConf_;
    // this.toggle=!this.toggle;
    this.tabOpened = [];
    localStorage.setItem('tabopened', JSON.stringify(this.tabOpened));
    this.startSchedular();
    // if (!environment.production) {
    //   this.ws.onMessage(
    //     (msg: MessageEvent) => {
    //       this.situation_data = JSON.parse(msg.data);
    //       console.log("socket connect" + msg.data);
    //     },
    //     { autoApply: false }
    //   );
    // }

  }
  ngOnDestroy(): void {
    // if (!environment.production) {
    //   this.ws.close();
    //   this.ws.onClose((msg: MessageEvent) => {
    //     this.ws = null;
    //     this.situation_data = [];
    //     console.log("socket disconnect");
    //   },
    //   );
    // }

    this.stopSchedular();
  }
  public subscription: Subscription;
  public startSchedular() {
    let timer = TimerObservable.create(3000, 30000);
    this.subscription = timer.subscribe(t => {
      this.scheduleTask();
    });
  }
  public scheduleTask() {
    this.timeRange = '';// this.getHeaders(this.timeServices_.getTimestampFromLastDays(this.days - 1).start, this.timeServices_.getTimestampFromLastDays(this.days - 1).end);
    this.timeRangeLastSevenDay = '' ;//this.getHeaders(this.timeServices_.getTimestampFromLastDays(6).start, this.timeServices_.getTimestampFromLastDays(6).end);
    this.timeRangeToday =  '';//this.getHeaders(this.timeServices_.getTimestampFromLastDays(0).start, this.timeServices_.getTimestampFromLastDays(0).end);

    this.getAllSystemOverview();
    this.getAllSystemOverviewToday();
    // this.getNMSOverview();
    this.getTechOverview();
  }

  public stopSchedular() {
    this.subscription.unsubscribe();
  }
  getAllSystemOverview() {
    this.summaryService.getAllSystemOverview().subscribe((res) => {
      if (res.Status) {
        this.systemViewmodel.Total_Event = res.data['Total Event'];
        this.systemViewmodel.Total_Incident = res.data['Total Incident'];
        this.systemViewmodel.Total_Automation = res.data['Total Automation'];
        this.systemViewmodel.Automation_Success = res.data['Automation Success'];
        this.systemViewmodel.Total_Enrichment = res.data['Total Enrichment'];
        this.systemViewmodel.Noise_Reduction = res.data['Noise Reduction'];
        this.systemViewmodel.Alert_Count = res.data['Alert Count'];
      } else {
        alert(res.msg);
      }
    }, (err) => {
    });
  }
  getcolor(persent) {
    // console.log(persent);
    let tempPersent = Number.parseFloat(persent);
    if (tempPersent >= 80.0) {
      //green
      return "1";
    } else if (tempPersent >= 60.0) {
      //yellow
      return "2";
    } else if (tempPersent >= 40.0) {
      return "3";
      //orange
    } else {
      return "4";
      //red
    }

    // return "bg-4";
  }
  getAllSystemOverviewToday() {
    this.summaryService.getAllSystemOverviewToday().subscribe((res) => {
      if (res.Status) {
        this.systemViewmodelToday.Total_Event = res.data['Total Event'];
        this.systemViewmodelToday.Total_Incident = res.data['Total Incident'];
        this.systemViewmodelToday.Total_Automation = res.data['Total Automation'];
        this.systemViewmodelToday.Automation_Success = res.data['Automation Success'];
        this.systemViewmodelToday.Total_Enrichment = res.data['Total Enrichment'];
        this.systemViewmodelToday.Noise_Reduction = res.data['Noise Reduction'];
        this.systemViewmodelToday.day = res.data['day'];
        this.systemViewmodelToday.Alert_Count = res.data['Alert Count'];
      } else {
        alert(res.msg);
      }
    }, (err) => {
    });
  }
  getNMSOverview() {
    this.startLoading();
    this.loading = true;
    this.summaryService.getNMSOverview().subscribe((res) => {
      if (res.Status) {
        this.systemViewNms = res.data;
        // this.systemViewService = res.data.service;
        this.completeLoading();
        this.loading = false;

      } else {
        this.loading = false;
        alert(res.msg);

      }
    }, (err) => {
      this.loading = false;
    });
  }
  changeDays() {
    // console.log("checkedd "+checked);
    if (this.days == 1) {
      this.days = 7;

    } else {
      this.days = 1;
    }
    this.timeRange = ''; //this.getHeaders(this.timeServices_.getTimestampFromLastDays(this.days - 1).start, this.timeServices_.getTimestampFromLastDays(this.days - 1).end);
    this.getTechOverview();
  }
  days = 1;
  timeRange = ""


  getHeaders(startDate, endDate) {
    const startTime = startDate;
    const endTime = endDate;
    let str = '';
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const myDateStart = new Date(startTime);
    const myDateEnd = new Date(endTime);
    str += '(';
    // if (this.performanceService_.timeRange.timeType == 'l1h') {
    str += this.getDatePart(myDateStart)['full'] + ' - ' + this.getDatePart(myDateEnd)['full'];
    // } else {
    //   str += this.getDatePart(myDateStart)['d_'] + '' + ' - ' + this.getDatePart(myDateEnd)['d_'] + '';
    // }

    str += ')'

    return str;
    // WAN Device Performance (Last 7 Days) - <from> to <to>
  }

  getDatePart(myDateStart: Date) {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const datePart_ = monthNames[myDateStart.getMonth()] + ' '
      + (myDateStart.getDate() < 10 ? '0' : '') + myDateStart.getDate() + ', ' + myDateStart.getFullYear();
    const timePart = (myDateStart.getHours() < 10 ? '0' : '') + myDateStart.getHours()
      + ':' + (myDateStart.getMinutes() < 10 ? '0' : '') + myDateStart.getMinutes() + ':'
      + (myDateStart.getSeconds() < 10 ? '0' : '') + myDateStart.getSeconds();

    return {
      d_: datePart_,
      t_: timePart,
      full: datePart_ + ' ' + timePart
    };
  }


  getTechOverview() {
    this.loading = true;
    this.startLoading();
    this.summaryService.getTechOverview(this.days).subscribe((res) => {
      if (res.Status) {
        // this.systemViewNms = res.data;
        this.systemViewService = res.data;
        this.completeLoading();
        this.loading = false;
        this.preOpenTab();
      } else {
        this.loading = false;
        alert(res.msg);

      }
    }, (err) => {
      this.loading = false;
    });
  }
  preOpenTab() {
    const tab = localStorage.getItem('tabopened');
    if (tab) {
      const tabJson = JSON.parse(tab);
      if (tabJson.length > 0) {
        tabJson.forEach(element => {
          this.getTechInnerData(element);
        });
      }
    }

  }
  tabOpened = [];
  getTechInnerData(techkey) {
    // this.blink("Notification",5);
    // console.log(techkey);

    this.loading = true;
    this.summaryService.getTechInnerData(techkey, this.days).subscribe((res) => {
      if (res.Status) {
        for (var i = 0; i < this.systemViewService.length; i++) {
          if (this.systemViewService[i].name == techkey) {
            this.systemViewService[i].inner_data = res.data;
          }
        }

        var flag: boolean = document.getElementById(techkey).hidden;
        document.getElementById(techkey).hidden = !flag;

        if (!this.tabOpened.includes(techkey)) {
          this.tabOpened.push(techkey);
        }
        localStorage.setItem('tabopened', JSON.stringify(this.tabOpened));
        this.loading = false;
      } else {
        this.loading = false;
        alert(res.msg);
      }
    }, (err) => {
    });
  }
  public navigateToReport(url, type, subtype) {
    // console.log(type);
    // console.log("arjun here"+subtype);
    // var url = "/widget/ireport/"+tab;
    // this.userService.eventtypeId=tab;
    // this.userService.eventTypeFilter=filter;
    // if(this.userService.eventTypeFilter=="name"){
    //   this.userService.eventtypeId="";
    //   this.userService.eventTypeName=tab;
    //   localStorage.setItem("eventtypeId","");
    //   localStorage.setItem("eventTypeName",tab);
    // }else if(this.userService.eventTypeFilter=="id"){
    //   this.userService.eventtypeId=tab;
    //   this.userService.eventTypeName="";
    //   localStorage.setItem("eventtypeId",tab);
    //   localStorage.setItem("eventTypeName","");
    //   url=url+"/eventdetail"; 
    // }else{
    //   this.userService.eventtypeId="";
    //   this.userService.eventTypeName="";
    //   localStorage.setItem("eventtypeId","");
    //   localStorage.setItem("eventTypeName","");
    // }
    // if(filter==''){
    // this.getEventsCounts();
    // }
    // this.userService.changeSelectionType({"clickName":filter});
    // if(filter==''||filter=='id'){
    //
    // }
    if (type == "nms") {
      // this.eventService.changeSelectionType({ "clickName": "event", "msgpattern": "", "host": "", "nms": subtype });

    }
    else {
      // this.eventService.changeSelectionType({ "clickName": "event", "msgpattern": "", "host": "", "nms": "" });

    }
    this.router.navigateByUrl(url);
  }
}
